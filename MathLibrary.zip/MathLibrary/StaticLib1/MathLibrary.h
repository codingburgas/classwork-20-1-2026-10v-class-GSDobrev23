#pragma once
int calculatePer(int �, int b, int c);
int calculatePlot(int a, int ha);