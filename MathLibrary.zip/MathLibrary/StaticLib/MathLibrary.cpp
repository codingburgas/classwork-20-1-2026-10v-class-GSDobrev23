#include<iostream>
#include"MathLibrary.h"
using namespace std;

int calcPer(int a, int b, int c)
{
	return a + b + c;

}

int calcPlot(int a, int ha)
{
	return (a * ha) / 2;
}
