#pragma once
int calcPer(int, int, int);

int calcPlot(int, int);